/* NAME:- Aniruddha Avhad.
   ROLL NO:-01. SE-IT */ 

#include <stdio.h>
#include <stdlib.h>
#include <p18f4550.h>

void main (void){
	int i,sum,n;
	sum = 0;
	sum = 0x0A + 0x04;
	TRISD = 0;
	PORTD = sum;
}